const promise = require('bluebird');
const async = require('async');
var ti = 0;

function time(cb)
		{
			ti = ti + 1000;
			setTimeout(function(){
				var x = Date.now();
				var y = x%2;
				if (y == 0)
					var l = ("c:"); 
				else
					var l = (x); 
				console.log(l);
				cb();
			},ti);
		};

let a = promise.promisify(time)
let p = a()
.then (()=>{
	return a();
})
.then (()=>{
	 return a();
})
.then (()=>{
	 return a();	
})
.then (()=>{
	return a();
})
.then (()=>{
	return a();
})
.then (()=>{
	return a();
})
.then (()=>{
	return a();
})
.then (()=>{
	return a();
})
.then (()=>{
	return a();
})
.then (()=>{
	a();
})
.catch((err)=>{
	console.log("ups ocirrio algo");
});

function sorry(cb)
	{
		console.log(0);
		console.log(1);
		cb();
	}
var aa = 0;
var bb = 1;
var cc = 0;
function fibo(cb)
		{
			cc = aa+bb;
			console.log(cc);
			aa = bb;
			bb = cc;
			
			cb ();
		};
let ini = promise.promisify(sorry)
let fi = promise.promisify(fibo)
let pr = ini()
.then (()=>{
	fi();
})
.then (()=>{
	fi();
})
.then (()=>{
	fi();
})
.then (()=>{
	fi();
})
.then (()=>{
	fi();
})
.then (()=>{
	fi();
})
.then (()=>{
	fi();
})
.then (()=>{
	fi();
})
.catch(()=>{
	console.log('uos ocurrio algo');
});
