
		function time(err,ti,cba)
		{
			var ti = ti;
			setTimeout(function(){
				var x = Date.now();
				var y = x%2;
				if (y == 0)
					var l = ("c:"); 
				else
					var l = (x); 
				return cba(null,l);
			},ti);
		};
		time (null,1000,
			function(err,li){
				console.log(li);
			return time(null,2000,
				function(err,li){
					console.log(li);
				return time(null,3000,
					function(err,li){
						console.log(li);
					return time(null,4000,
						function(err,li){
							console.log(li);
						return time(null,5000,
							function(err,li){
								console.log(li);
							return time(null,6000,
								function(err,li){
									console.log(li);
								return time(null,7000,
									function(err,li){
										console.log(li);
									return time(null,8000,
										function(err,li){
											console.log(li);
										return time(null,9000,
											function(err,li){
												console.log(li);
											return time(null,10000,
												function(err,li){
													console.log(li);
												});
											});
										});
									});
								});
							});
						});
					});
				});
			});
		
		
		function fibo(err,a,b,cb)
		{
			c = a+b;
			return cb (null,c)
		};
		fibo (null,0,0,
			function(err,c){
				console.log(err,c);
			return fibo(null,0,1,
				function(err,c){
					console.log(err,c);
				return fibo(null,0,1,
					function(err,c){
						console.log(err,c);
					return fibo(null,1,1,
						function(err,c){
							console.log(err,c);
						return fibo(null,1,2,
							function(err,c){
								console.log(err,c);
								return fibo(null,2,3,
									function(err,c){
										console.log(err,c);
									return fibo(null,3,5,
										function(err,c){
											console.log(err,c);
										return fibo(null,5,8,
											function(err,c){
												console.log(err,c);
											return fibo(null,8,13,
												function(err,c){
													console.log(err,c);
												return fibo(null,13,21,
													function(err,c){
														console.log(err,c);
												});
											});
										});
									});
								});
							});
						});
					});
				});
			});
		