const promise = require('bluebird');
const async = require('async');
const readline = require('readline');

let input = readline.createInterface({
	input: process.stdin,
	output: process.stdout,
});

var can = 0;
var pasteles = [];
class pastel{
		constructor(sabor,tamaño,relleno){
			this.sabor = sabor;
			this.tamaño = tamaño;
			this.relleno = relleno;
		}
	}
function lista(orden,nombre)
{console.log(nombre);
	if(orden == 'si')
	{
		can++;
		input.question("Dame sabor ",(sabor)=>{
			if(sabor == 'salir'){ var err = 'adios'; throw err;}
			console.log(sabor);
			input.question("Dame tamaño ",(tamaño)=>{
				if(sabor == 'salir'){ var err = 'adios'; throw err;}
					console.log(tamaño);
				input.question("Dame relleno ",(relleno)=>{
					if(sabor == 'salir'){ var err = 'adios'; throw err;}
					console.log(relleno);
					let can = new pastel(sabor,tamaño,relleno);
					pasteles.push(can);
					console.log(pasteles);
					ini(nombre);
				});	

			});
		});
	}
	else { var err = 'inva'; throw err;}
}
function total()
{
	var nu = pasteles.length;
	if(nu == 0)
	{
		console.log('no tienes ningun pastel es tu lista, agrega los que quieras');
		preg();
	}
	else{
		if(nu%2==0)
		{
			let can = new pastel('especial','extragrande','arcoiris');
			pasteles.push(can);
			console.log('Felicidades, se te dio un pastel especial');
			console.log(pasteles);
			preg();
		}
		else{
			if(nu%3==0)
			{
				console.log('lo sentimos, no podemos mostrarte tu lista');
				preg();
			}
			else 
				console.log(pasteles);
		}
	}
	
}
function bien(cb){
	console.log('¡Bienvenido!');
	input.question("¿Cómo te llamas? :) ",(nombre)=>{
		//var nombre = nom;
		return cb(null,nombre);
	});
}

function preg(nombre,cb)
{
	input.question("¡Hola "+nombre+"! ¿Deseas agregar un pastel a tu lista?('si'/'no'). Si quieres salir en cualquier momento, escribe 'salir'",(orden)=>{
		console.log(orden)
		if(orden == 'salir'){
			console.log('adios');
			process.exit(0);
		}
        else
			if (nombre == undefined)
				if (orden == 'si')
				   li(orden,nombre);
			    else
					to();
			else 	
			    return cb(null,orden,nombre);
			
	    }
	)
}
let li = promise.promisify(lista)
let to = promise.promisify(total)
let ini = promise.promisify(preg)
let bi = promise.promisify(bien)
let p = bi()
.catch(()=>{
	console.log('lo sentimos, algo salió mal :c');
})
.then((nombre)=>{
	return ini(nombre);
})
.catch((err)=>{
	process.exit(0);
})
.then ((orden,nombre)=>{
	console.log('hola');
	console.log(orden);
	if (orden == 'no')
		return to();
	else
	    return li(orden,nombre);
})
.catch((err)=>{
	if (err != 'adios')
	{
		console.log('comando invalido');
		preg();
	}
	else
	    process.exit(0);
})
