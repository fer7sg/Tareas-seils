const readline = require('readline');

let input = readline.createInterface({
	input: process.stdin,
	output: process.stdout,
});
var eventos=[];
function datos(orden)
{	
	if(orden==='añadir'|| orden==='eliminar')
	{
		input.question("Dame nombre del evento",(nombre)=>{
				if(nombre == 'salir')
					process.exit(0);
				console.log(nombre);
				input.question("Dame fecha del evento dd/mm/aaaa",(fecha)=>{
					if(fecha == 'salir')
						process.exit(0);
						console.log(fecha);
					input.question("Dame hora del evento aa:bb",(hora)=>{
						if(hora == 'salir')
							process.exit(0);
							console.log(hora);
							if(orden == 'añadir')
								añadir(nombre,fecha,hora);
							if(orden == 'eliminar')
								eliminar(nombre,fecha,hora);
					});

				});
			});
	}
	else{
		if(orden === 'ver'){
			input.question("Inserta el nombre/fecha(dd/mm/aaaa)/hora(aa:bb) del evento que buscas",(busca)=>{
				if(busca == 'salir')
					process.exit(0);
				else
					ver(busca);
				});
		}
		else{
			console.log('comando invalido');
			preg();
		}
	}
}

function ver(busca)
{
	//eventos.length;
	if(eventos != '')
	{
		console.log('si');
		var con = 0;
		var myRe = new RegExp(busca+"+", "g");
		for (let a of eventos){
			var myArray = myRe.exec(a);
			con++;
			if(myArray!=null)
			{
				console.log(a);
				preg();
			}
			else {
				if(eventos.lenght == con)
				{
					console.log('no se encontró tu evento');
					preg();
				}
			}
		}
	}
	else{
		console.log('no');
		console.log('no tienes eventos');
		preg();
	}
}
function añadir(nombre,fecha,hora)
{
	var da = nombre+' '+fecha+' '+hora;
	var res = eventos.indexOf(da);
	if(res != -1){
		console.log('ese evento ya existe');
		preg();
	}
	else{
		eventos.push(da);
		console.log(eventos);
		preg();
	}
}
function eliminar(nombre,fecha,hora)
{
	if(eventos.lenght != 0){	
		var da = nombre+' '+fecha+' '+hora;
		var res = eventos.indexOf(da);
		if(res != -1)
		{
			eventos.splice(res,1);
			console.log(eventos);
			console.log('se eliminó tu evento');
			preg();
		}
		else
		{
			console.log('no se encontró tu evento');
			preg();
		}
	}
	else{
		console.log('no tienes eventos');
		preg();
	}
}
function preg()
{
	input.question("¿Que deseas hacer? 'ver','añadir' o 'eliminar'. Si en cuanlquier momento quieres salir, solo escribe 'salir'",(orden)=>{
		console.log(orden)
	if(orden == 'salir')
		process.exit(0);
	else
		datos(orden);
	});
}
preg();
