const async = require('async');
var ti=0;
function time(cb)
		{
			ti = ti + 1000;
			console.log(ti);
			setTimeout(function(){
				var x = Date.now();
				var y = x%2;
				if (y == 0)
					var l = ("c:"); 
				else
					var l = (x); 
				console.log(l);
				cb();
			},ti);
		};
async.waterfall([
	time,
	time,
	time,
	time,
	time,
	time,
	time,
	time,
	time,
	time,
],(err,cb)=>{
	if(err){
		console.log('no es hora de cafe');
		return;
	}
	console.log('el higlight de midia se acabo');	
});
function sorry(cb)
	{
		console.log(0);
		console.log(1);
		cb();
	}
var a = 0;
var b = 1;
var c = 0;
function fibo(cb)
		{
			c = a+b;
			console.log(c);
			a = b;
			b = c;
			
			cb ();
		};
async.waterfall([
	sorry,
	fibo,
	fibo,
	fibo,
	fibo,
	fibo,
	fibo,
	fibo,
	fibo,
],(err,cb)=>{
	if(err){
		console.log('no es hora de cafe');
		return;
	}
	console.log('el higlight de midia se acabo');	
});